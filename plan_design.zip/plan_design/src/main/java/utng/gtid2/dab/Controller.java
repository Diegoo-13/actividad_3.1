package utng.gtid2.dab;

import java.io.IOException;
import javafx.fxml.FXML;

public class Controller {

    @FXML
    private void switchToSecondary() throws IOException {
        App.setRoot("plan_design");
    }
}

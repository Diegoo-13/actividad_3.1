module utng.gtid2.dab {
    requires javafx.controls;
    requires javafx.fxml;

    opens utng.gtid2.dab to javafx.fxml;
    exports utng.gtid2.dab;
}
